import 'package:flutter/material.dart';
import 'package:gpa/backend.dart';
import 'package:provider/provider.dart';
import 'package:gpa/course_data.dart';
import 'package:gpa/main.dart';


class gpaScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return  Scaffold(
    floatingActionButton: FloatingActionButton(
    child: Icon(Icons.add),
    onPressed: () {
      Provider.of<courseData>(context,listen: false).addcourse("A", 3);
    }), //add row when you press it
    appBar: AppBar(
    title: Text('GPA'),
    backgroundColor: Colors.deepOrangeAccent,
    ),
    body: Column(
      children: [
        therows(),
        Container(
          child: FlatButton(color: Colors.black,onPressed: (){
            functions().fu(Provider.of<courseData>(context,listen: false).allcourses);

          },),
        ),//test
      ],
    ));

  }
}
