import 'package:flutter/material.dart';
import 'package:gpa/listofGrades.dart';
import 'package:gpa/main.dart';
class fun {



}